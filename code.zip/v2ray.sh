#!/bin/bash

args=$@
is_sh_ver=v4.14

. /etc/v2ray/sh/src/init.sh
